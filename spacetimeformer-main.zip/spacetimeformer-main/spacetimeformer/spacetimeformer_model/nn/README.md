The core model code is based on Informer (https://github.com/zhouhaoyi/Informer2020). [ArXiv](https://arxiv.org/abs/2012.07436)
