Credits to @sooftware for the LR Scheduling code: https://github.com/sooftware/pytorch-lr-scheduler
