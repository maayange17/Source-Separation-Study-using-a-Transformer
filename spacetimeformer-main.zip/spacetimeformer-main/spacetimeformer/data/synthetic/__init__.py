from .synthetic import SyntheticData
