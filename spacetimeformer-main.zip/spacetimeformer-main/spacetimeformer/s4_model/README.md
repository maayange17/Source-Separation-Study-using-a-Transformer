### S4 

Code: [https://github.com/HazyResearch/state-spaces](https://github.com/HazyResearch/state-spaces)

Paper: [Efficiently Modeling Long Sequences with Structured State Spaces](https://arxiv.org/abs/2111.00396)
